setTimeout(function() {
    console.log(1);
}, 1000);

console.log(2);
  