const mathObj = require('./math');

console.log(mathObj.add(5, 3));
console.log(mathObj.multiply(5, 3));

 


 